export default {
  content: ["./index.html","./src/**/*.{js,jsx}"],
  theme: { extend: { fontFamily: { sans: ['Plus Jakarta Sans','sans-serif'], mono: ['JetBrains Mono','monospace'] } } },
  plugins: []
}
