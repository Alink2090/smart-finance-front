import { useState, useEffect, useCallback, useMemo } from 'react'
import { useAuth } from '../context/AuthContext'
import { analyticsAPI, transactionsAPI, categoriesAPI } from '../services/api'
import { useFinanceCalcs } from '../hooks/useFinanceData'
import { ProgressRow, EmptyState, Sk } from '../components/ui'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'

const formatXOF = (n, digits = 0) =>
  new Intl.NumberFormat('fr-FR', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(Number(n) || 0) + ' FCFA'

const fmt = n => formatXOF(n, 0)
const fmtFull = n => formatXOF(n, 2)
const fmtPct = n => `${(n ?? 0).toFixed(1)}%`
const fmtDate= d => d ? new Date(d+'T00:00').toLocaleDateString('fr-FR',{ day:'2-digit', month:'2-digit', year:'numeric' }) : '—'
const CAT_PALETTE = ['#7c6cfc','#f5476a','#22d3a0','#f59e0b','#38bdf8','#a78bfa','#fb923c','#4ade80']

// ── Export PDF (mock print) ────────────────────────────────────────────────────
function exportPDF() {
  window.print()
}

export default function Reports() {
  const { user } = useAuth()
  const [stats,     setStats]     = useState(null)
  const [monthly,   setMonthly]   = useState([])
  const [catExp,    setCatExp]    = useState([])
  const [txs,       setTxs]       = useState([])
  const [loading,   setLoading]   = useState(true)
  const [err,       setErr]       = useState(null)
  const [dateFrom,  setDateFrom]  = useState('')
  const [dateTo,    setDateTo]    = useState('')
  const [typeFilter,setTypeFilter]= useState('all')
  const [sortCol,   setSortCol]   = useState('date')
  const [sortDir,   setSortDir]   = useState('desc')
  const [page,      setPage]      = useState(1)
  const PAGE_SIZE = 15

  const exportTransactionsXLSX = async () => {
    try {
      const res = await transactionsAPI.exportXLSX({
        user_id: user.id,
        date_from: dateFrom,
        date_to: dateTo,
        type: typeFilter
      })

      // 🔥 Création du fichier à télécharger
      const blob = new Blob([res.data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      })

      const url = window.URL.createObjectURL(blob)

      const link = document.createElement('a')
      link.href = url
      link.download = `rapport_${new Date().toLocaleDateString('fr-FR')}.xlsx`

      document.body.appendChild(link)
      link.click()
      link.remove()

      window.URL.revokeObjectURL(url)

    } catch (err) {
      console.error('Erreur export:', err)
    }
  }

  const load = useCallback(async () => {
    setLoading(true); setErr(null)
    try {
      const [d, m, c, t] = await Promise.all([
        analyticsAPI.dashboard(user.id),
        analyticsAPI.monthlyExpenses(user.id),
        analyticsAPI.categoryExpenses(user.id),
        transactionsAPI.getAll(user.id),
      ])
      setStats(d?.data ?? d)
      setMonthly(Array.isArray(m) ? m : (m?.data ?? []))
      setCatExp(Array.isArray(c) ? c : (c?.data ?? []))
      setTxs(Array.isArray(t) ? t : (t?.data ?? t?.transactions ?? []))
    } catch(e) { setErr(e.message) }
    finally { setLoading(false) }
  }, [user.id])

  useEffect(() => { load() }, [load])

  const calcs = useFinanceCalcs({ stats, monthly, catExp })
  const { income, expenses, savingsRate, expenseRatio, avgMonthlyExpense, topCatName, topCatShare } = calcs

  const pieData = catExp.map((c,i) => ({
    name:  c.category?.name ?? c.category ?? c.name ?? `Cat ${i+1}`,
    value: c.amount ?? c.total ?? 0,
    color: c.category?.color ?? c.color ?? CAT_PALETTE[i % CAT_PALETTE.length],
  })).sort((a,b) => b.value - a.value)
  const totalCatExp = pieData.reduce((s,d)=>s+d.value, 0)

  // Filtrage + tri transactions
  const filteredTxs = useMemo(() => {
    let res = [...txs]
    if (dateFrom) res = res.filter(t => t.date && t.date >= dateFrom)
    if (dateTo)   res = res.filter(t => t.date && t.date <= dateTo)
    if (typeFilter !== 'all') res = res.filter(t => t.type === typeFilter)
    res.sort((a,b) => {
      let va, vb
      if (sortCol === 'date')   { va = a.date ?? ''; vb = b.date ?? '' }
      else if (sortCol === 'amount') { va = a.amount ?? 0; vb = b.amount ?? 0 }
      else if (sortCol === 'title')  { va = a.title ?? ''; vb = b.title ?? '' }
      else { va = ''; vb = '' }
      if (va < vb) return sortDir==='asc' ? -1 : 1
      if (va > vb) return sortDir==='asc' ? 1 : -1
      return 0
    })
    return res
  }, [txs, dateFrom, dateTo, typeFilter, sortCol, sortDir])

  const totalPages = Math.ceil(filteredTxs.length / PAGE_SIZE)
  const paginated  = filteredTxs.slice((page-1)*PAGE_SIZE, page*PAGE_SIZE)

  const toggleSort = col => {
    if (sortCol === col) setSortDir(d => d==='asc'?'desc':'asc')
    else { setSortCol(col); setSortDir('desc') }
    setPage(1)
  }
  const SortIcon = ({ col }) => sortCol===col ? (sortDir==='asc'?'↑':'↓') : '↕'

  // KPIs du rapport
  const reportIncome  = filteredTxs.filter(t=>t.type==='income').reduce((s,t)=>s+(t.amount??0),0)
  const reportExpense = filteredTxs.filter(t=>t.type==='expense').reduce((s,t)=>s+(t.amount??0),0)

  const today = new Date().toLocaleDateString('fr-FR',{ day:'numeric', month:'long', year:'numeric' })

  return (
    <div className="fade-up" style={{ padding:24 }}>

      {/* Header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:24, flexWrap:'wrap', gap:12 }}>
        <div>
          <div className="page-title">Rapports</div>
          <div className="page-subtitle">Synthèse financière · Généré le {today}</div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <button className="btn btn-ghost" onClick={()=>exportTransactionsXLSX(filteredTxs)} disabled={loading||filteredTxs.length===0}>
            <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Export CSV
          </button>
          <button className="btn btn-primary" onClick={exportPDF}>
            <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            Imprimer / PDF
          </button>
        </div>
      </div>

      {err && <div className="error-box" style={{ marginBottom:20 }}>{err} <button className="btn btn-ghost btn-sm" style={{ marginLeft:8 }} onClick={load}>Réessayer</button></div>}

      {/* KPIs globaux */}
      <div style={{ display:'flex', gap:12, marginBottom:20, flexWrap:'wrap' }}>
        {[
          { label:'Revenus totaux',    value:loading?'—':fmt(income),     color:'#22d3a0', sub:'Cette période' },
          { label:'Dépenses totales',  value:loading?'—':fmt(expenses),   color:'#f5476a', sub:'Cette période' },
          { label:'Solde net',         value:loading?'—':fmt(income-expenses), color: income-expenses>=0?'#22d3a0':'#f5476a', sub:'Revenus − Dépenses' },
          { label:'Taux d\'épargne',   value:loading?'—':fmtPct(savingsRate), color:'#7c6cfc', sub:'Objectif : 20%' },
          { label:'Moy. mens. dép.',   value:loading?'—':fmt(avgMonthlyExpense), color:'#f59e0b', sub:'Par mois' },
          { label:'Top catégorie',     value:loading||!topCatName?'—':topCatName, color:'var(--text)', sub:loading?'':fmtPct(topCatShare)+' des dépenses' },
        ].map((s,i) => (
          <div key={i} className="card" style={{ flex:'1 1 130px', padding:'16px 18px', borderLeft:`2px solid ${s.color}` }}>
            {loading ? <><Sk h={12} w="60%" style={{ marginBottom:8 }}/><Sk h={22} w="80%"/></> : <>
              <div style={{ fontSize:10, fontWeight:600, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.04em', marginBottom:6 }}>{s.label}</div>
              <div style={{ fontSize:18, fontWeight:800, color:s.color, fontFamily:'JetBrains Mono,monospace', lineHeight:1.1 }}>{s.value}</div>
              <div style={{ fontSize:11, color:'var(--text3)', marginTop:4 }}>{s.sub}</div>
            </>}
          </div>
        ))}
      </div>

      {/* Breakdown catégories + pie */}
      <div style={{ display:'flex', gap:16, marginBottom:16, flexWrap:'wrap' }}>
        <div className="card" style={{ flex:'2 1 300px', padding:24 }}>
          <div style={{ marginBottom:18 }}>
            <div style={{ fontSize:15, fontWeight:700, color:'var(--text)' }}>Répartition par catégorie</div>
            <div style={{ fontSize:13, color:'var(--text2)', marginTop:3 }}>Dépenses totales {fmt(totalCatExp)}</div>
          </div>
          {loading
            ? [1,2,3,4].map(i=><Sk key={i} h={18} style={{ marginBottom:16 }}/>)
            : pieData.length === 0
              ? <EmptyState icon="📂" title="Aucune catégorie"/>
              : pieData.map((d,i) => <ProgressRow key={i} label={d.name} value={d.value} max={totalCatExp} color={d.color}/>)
          }
        </div>

        <div className="card" style={{ flex:'1 1 220px', padding:24 }}>
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:15, fontWeight:700, color:'var(--text)' }}>Répartition visuelle</div>
          </div>
          {loading ? <Sk h={180}/> : pieData.length === 0 ? <EmptyState icon="🥧" title="Aucune donnée"/> :
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={78} paddingAngle={2} dataKey="value">
                  {pieData.map((d,i) => <Cell key={i} fill={d.color}/>)}
                </Pie>
                <Tooltip formatter={v=>[fmt(v),'Montant']} contentStyle={{ background:'var(--surface2)', border:'1px solid var(--border2)', borderRadius:8, fontSize:13 }}/>
              </PieChart>
            </ResponsiveContainer>
          }
          {!loading && (
            <div style={{ display:'flex', flexDirection:'column', gap:5, marginTop:10 }}>
              {pieData.slice(0,4).map((d,i)=>(
                <div key={i} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', fontSize:12 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                    <span style={{ width:7, height:7, borderRadius:'50%', background:d.color, display:'inline-block' }}/>
                    <span style={{ color:'var(--text2)' }}>{d.name}</span>
                  </div>
                  <span style={{ fontWeight:700, color:'var(--text)', fontFamily:'JetBrains Mono,monospace' }}>
                    {totalCatExp > 0 ? fmtPct((d.value/totalCatExp)*100) : '—'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Résumé mensuel */}
      {!loading && monthly.length > 0 && (
        <div className="card" style={{ padding:24, marginBottom:16 }}>
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:15, fontWeight:700, color:'var(--text)' }}>Résumé mensuel</div>
          </div>
          <div style={{ overflowX:'auto' }}>
            <table style={{ width:'100%', borderCollapse:'collapse', minWidth:500 }}>
              <thead>
                <tr style={{ borderBottom:'1px solid var(--border)' }}>
                  {['Mois','Revenus','Dépenses','Solde','Épargne'].map(h=>(
                    <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:600, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.05em' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {monthly.map((m,i)=>{
                  const sol    = (m.income??0) - (m.expenses??0)
                  const saving = (m.income??0) > 0 ? (sol/(m.income??1))*100 : 0
                  return (
                    <tr key={i} className="table-row">
                      <td style={{ padding:'11px 14px', fontWeight:600, color:'var(--text)', fontSize:13 }}>{m.month}</td>
                      <td style={{ padding:'11px 14px', fontFamily:'JetBrains Mono,monospace', color:'#22d3a0', fontSize:13 }}>{fmt(m.income??0)}</td>
                      <td style={{ padding:'11px 14px', fontFamily:'JetBrains Mono,monospace', color:'#f5476a', fontSize:13 }}>{fmt(m.expenses??0)}</td>
                      <td style={{ padding:'11px 14px', fontFamily:'JetBrains Mono,monospace', color:sol>=0?'#22d3a0':'#f5476a', fontWeight:700, fontSize:13 }}>{fmt(sol)}</td>
                      <td style={{ padding:'11px 14px', fontSize:13 }}>
                        <span style={{ color: saving>=20?'#22d3a0':saving>=10?'#f59e0b':'#f5476a', fontWeight:600 }}>
                          {fmtPct(saving)}
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Filtres transactions */}
      <div className="card" style={{ padding:14, marginBottom:14, display:'flex', gap:10, flexWrap:'wrap', alignItems:'center' }}>
        <div style={{ display:'flex', alignItems:'center', gap:6, flex:'1 1 240px' }}>
          <span style={{ fontSize:11, fontWeight:600, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.04em', whiteSpace:'nowrap' }}>Du</span>
          <input className="input" type="date" value={dateFrom} onChange={e=>{setDateFrom(e.target.value);setPage(1)}} style={{ flex:1 }}/>
          <span style={{ fontSize:11, fontWeight:600, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.04em' }}>Au</span>
          <input className="input" type="date" value={dateTo}   onChange={e=>{setDateTo(e.target.value);setPage(1)}}   style={{ flex:1 }}/>
        </div>
        <select className="input" style={{ width:'auto', flex:'0 0 140px' }} value={typeFilter} onChange={e=>{setTypeFilter(e.target.value);setPage(1)}}>
          <option value="all">Tous types</option>
          <option value="income">Revenus</option>
          <option value="expense">Dépenses</option>
        </select>
        <div style={{ display:'flex', gap:10, marginLeft:'auto', alignItems:'center', flexWrap:'wrap' }}>
          <span style={{ fontSize:12, color:'var(--text3)' }}>{filteredTxs.length} transaction{filteredTxs.length!==1?'s':''}</span>
          {(dateFrom||dateTo||typeFilter!=='all') && (
            <button className="btn btn-ghost btn-sm" onClick={()=>{setDateFrom('');setDateTo('');setTypeFilter('all');setPage(1)}}>Réinitialiser</button>
          )}
          {filteredTxs.length > 0 && (
            <div style={{ fontSize:12, color:'var(--text3)', padding:'5px 12px', background:'var(--surface2)', borderRadius:8, border:'1px solid var(--border)' }}>
              Revenus : <strong style={{ color:'#22d3a0' }}>{fmt(reportIncome)}</strong>
              {' · '}Dépenses : <strong style={{ color:'#f5476a' }}>{fmt(reportExpense)}</strong>
            </div>
          )}
        </div>
      </div>

      {/* Table transactions */}
      <div className="card" style={{ overflow:'hidden' }}>
        {loading ? (
          <div style={{ padding:20, display:'flex', flexDirection:'column', gap:10 }}>
            {[1,2,3,4,5].map(i=><Sk key={i} h={42} r={8}/>)}
          </div>
        ) : filteredTxs.length === 0 ? (
          <EmptyState icon="📭" title="Aucune transaction" message="Ajoutez des transactions ou ajustez les filtres."/>
        ) : (
          <div style={{ overflowX:'auto' }}>
            <table style={{ width:'100%', borderCollapse:'collapse', minWidth:620 }}>
              <thead>
                <tr style={{ borderBottom:'1px solid var(--border)' }}>
                  {[
                    { label:'Date',    col:'date'   },
                    { label:'Titre',   col:'title'  },
                    { label:'Catégorie', col:null   },
                    { label:'Type',    col:null     },
                    { label:'Montant', col:'amount' },
                    { label:'Méthode', col:null     },
                  ].map(h=>(
                    <th key={h.label} onClick={h.col ? ()=>toggleSort(h.col) : undefined} style={{
                      padding:'11px 14px', textAlign:'left', fontSize:11, fontWeight:600,
                      color: h.col && sortCol===h.col ? 'var(--accent2)' : 'var(--text3)',
                      textTransform:'uppercase', letterSpacing:'.05em', whiteSpace:'nowrap',
                      cursor: h.col ? 'pointer' : 'default',
                      userSelect:'none',
                    }}>
                      {h.label} {h.col && <span style={{ opacity:.6 }}><SortIcon col={h.col}/></span>}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {paginated.map((tx,i)=>{
                  const catName  = tx.category  ?? '—'
                  const catColor = tx.category_color ?? '#888'
                  return (
                    <tr key={tx.id ?? i} className="table-row">
                      <td style={{ padding:'11px 14px', fontSize:12, color:'var(--text3)', fontFamily:'JetBrains Mono,monospace', whiteSpace:'nowrap' }}>{fmtDate(tx.date)}</td>
                      <td style={{ padding:'11px 14px', fontSize:13, fontWeight:600, color:'var(--text)' }}>{tx.title ?? '—'}</td>
                      <td style={{ padding:'11px 14px' }}>
                        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                          <span style={{ width:7, height:7, borderRadius:'50%', background:catColor, display:'inline-block', flexShrink:0 }}/>
                          <span style={{ fontSize:12, color:'var(--text2)' }}>{catName}</span>
                        </div>
                      </td>
                      <td style={{ padding:'11px 14px' }}>
                        <span style={{ fontSize:11, fontWeight:700, padding:'2px 8px', borderRadius:100,
                          background: tx.type==='income'?'rgba(34,211,160,.12)':'rgba(245,71,106,.12)',
                          color: tx.type==='income'?'#22d3a0':'#f5476a',
                        }}>
                          {tx.type==='income' ? 'Revenu' : 'Dépense'}
                        </span>
                      </td>
                      <td style={{ padding:'11px 14px', textAlign:'right', fontSize:13, fontWeight:700, fontFamily:'JetBrains Mono,monospace',
                        color: tx.type==='income' ? '#22d3a0' : '#f5476a' }}>
                        {tx.type==='income'?'+':'-'}{fmtFull(tx.amount)}
                      </td>
                      <td style={{ padding:'11px 14px', fontSize:12, color:'var(--text3)' }}>{tx.payment_method ?? '—'}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>

            {/* Pagination */}
            {totalPages > 1 && (
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 14px', borderTop:'1px solid var(--border)' }}>
                <span style={{ fontSize:12, color:'var(--text3)' }}>
                  Page {page} / {totalPages} · {filteredTxs.length} transactions
                </span>
                <div style={{ display:'flex', gap:6 }}>
                  <button className="btn btn-ghost btn-sm" disabled={page===1} onClick={()=>setPage(1)}>«</button>
                  <button className="btn btn-ghost btn-sm" disabled={page===1} onClick={()=>setPage(p=>p-1)}>‹</button>
                  {Array.from({ length:Math.min(5,totalPages) }, (_,i) => {
                    const p = Math.min(Math.max(page-2, 1) + i, totalPages)
                    return p
                  }).filter((p,i,a)=>a.indexOf(p)===i).map(p=>(
                    <button key={p} className="btn btn-ghost btn-sm" onClick={()=>setPage(p)} style={{
                      background: page===p ? 'rgba(124,108,252,.2)' : '',
                      color: page===p ? 'var(--accent2)' : '',
                      border: page===p ? '1px solid rgba(124,108,252,.25)' : '',
                      minWidth:32
                    }}>{p}</button>
                  ))}
                  <button className="btn btn-ghost btn-sm" disabled={page===totalPages} onClick={()=>setPage(p=>p+1)}>›</button>
                  <button className="btn btn-ghost btn-sm" disabled={page===totalPages} onClick={()=>setPage(totalPages)}>»</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
