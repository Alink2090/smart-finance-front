import { useState, useEffect, useCallback, useMemo } from 'react'
import { useAuth } from '../context/AuthContext'
import { analyticsAPI, budgetsAPI } from '../services/api'
import { useFinanceCalcs, generateInsights } from '../hooks/useFinanceData'
import { InsightCard, EmptyState, Sk, StatCard } from '../components/ui'

const GROUPS = [
  { key:'all',           label:'Tout',          icon:'⊞' },
  { key:'alerts',        label:'Alertes',        icon:'⚠' },
  { key:'opportunities', label:'Opportunités',   icon:'💡' },
  { key:'trends',        label:'Tendances',      icon:'📈' },
]

const GROUP_META = {
  alerts:        { title:'Alertes',       subtitle:'Actions urgentes à prendre',         color:'#f5476a', bg:'rgba(245,71,106,.06)'  },
  opportunities: { title:'Opportunités',  subtitle:'Pistes d\'optimisation de votre budget', color:'#38bdf8', bg:'rgba(56,189,248,.06)'  },
  trends:        { title:'Tendances',     subtitle:'Évolutions de vos habitudes',        color:'#22d3a0', bg:'rgba(34,211,160,.06)'  },
}

export default function Insights() {
  const { user } = useAuth()
  const [stats,   setStats]   = useState(null)
  const [monthly, setMonthly] = useState([])
  const [catExp,  setCatExp]  = useState([])
  const [budgets, setBudgets] = useState([])
  const [loading, setLoading] = useState(true)
  const [err,     setErr]     = useState(null)
  const [activeGroup, setActiveGroup] = useState('all')
  const [dismissed,   setDismissed]   = useState(new Set())

  const load = useCallback(async () => {
    setLoading(true); setErr(null)
    try {
      const [d, m, c, b] = await Promise.all([
        analyticsAPI.dashboard(user.id),
        analyticsAPI.monthlyExpenses(user.id),
        analyticsAPI.categoryExpenses(user.id),
        budgetsAPI.getAll(user.id).catch(() => []),
      ])
      setStats(d?.data ?? d)
      setMonthly(Array.isArray(m) ? m : (m?.data ?? []))
      setCatExp(Array.isArray(c) ? c : (c?.data ?? []))
      setBudgets(Array.isArray(b) ? b : (b?.data ?? b?.budgets ?? []))
    } catch(e) { setErr(e.message) }
    finally { setLoading(false) }
  }, [user.id])

  useEffect(() => { load() }, [load])

  const calcs = useFinanceCalcs({ stats, monthly, catExp })

  const normalizedBudgets = useMemo(() => {
    return (budgets || []).map(b => {
      const isSaving = b.type === 'saving'

      const target = isSaving
        ? (b.target_amount ?? 0)
        : (b.limit_amount ?? 0)

      const spent = b.spent_amount ?? b.saved_amount ?? 0

      return {
        ...b,
        _computed: {
          target,
          spent,
          remaining: target - spent,
          progress: target > 0 ? (spent / target) * 100 : 0
        }
      }
    })
  }, [budgets])

  const allInsights = useMemo(
    () => generateInsights(calcs, normalizedBudgets).filter(i => !dismissed.has(i.id)),
    [calcs, normalizedBudgets, dismissed]
  )

  const filtered = useMemo(
    () => activeGroup === 'all' ? allInsights : allInsights.filter(i => i.group === activeGroup),
    [allInsights, activeGroup]
  )

  const counts = useMemo(() => ({
    all:           allInsights.length,
    alerts:        allInsights.filter(i=>i.group==='alerts').length,
    opportunities: allInsights.filter(i=>i.group==='opportunities').length,
    trends:        allInsights.filter(i=>i.group==='trends').length,
  }), [allInsights])

  const dismiss = (id) => setDismissed(prev => new Set([...prev, id]))

  const formatXOF = (n, digits = 0) =>
    new Intl.NumberFormat('fr-FR', {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits
    }).format(Number(n) || 0) + ' FCFA'

  const fmt = n => formatXOF(n, 0)
  const { income, expenses, savingsRate, balance } = calcs

  return (
    <div className="fade-up" style={{ padding:24 }}>

      {/* Header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:24, flexWrap:'wrap', gap:12 }}>
        <div>
          <div className="page-title">Insights</div>
          <div className="page-subtitle">Analyse intelligente de votre situation financière</div>
        </div>
        <button className="btn btn-ghost" onClick={load} disabled={loading}>
          {loading ? <span className="spinner"/> : '↺'} Actualiser
        </button>
      </div>

      {err && <div className="error-box" style={{ marginBottom:20 }}>{err}</div>}

      {/* Score financier synthétique */}
      {!loading && stats && (
        <div className="card" style={{ padding:24, marginBottom:20, borderLeft:'2px solid #7c6cfc' }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:16 }}>
            <div>
              <div style={{ fontSize:13, fontWeight:600, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.04em', marginBottom:8 }}>Situation financière du mois</div>
              <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                {[
                  { icon: balance >= 0 ? '✓' : '✕', label: balance >= 0 ? 'Solde positif' : 'Solde négatif', ok: balance >= 0 },
                  { icon: savingsRate >= 20 ? '✓' : '!', label: `Épargne ${savingsRate.toFixed(0)}%`, ok: savingsRate >= 20 },
                  { icon: counts.alerts === 0 ? '✓' : '⚠', label: counts.alerts === 0 ? 'Aucune alerte' : `${counts.alerts} alerte${counts.alerts>1?'s':''}`, ok: counts.alerts === 0 },
                ].map((s,i) => (
                  <span key={i} style={{
                    display:'inline-flex', alignItems:'center', gap:6, padding:'6px 12px',
                    borderRadius:100, fontSize:12, fontWeight:600,
                    background: s.ok ? 'rgba(34,211,160,.1)' : 'rgba(245,71,106,.1)',
                    color: s.ok ? '#22d3a0' : '#f5476a',
                    border: `1px solid ${s.ok ? 'rgba(34,211,160,.2)' : 'rgba(245,71,106,.2)'}`,
                  }}>
                    {s.icon} {s.label}
                  </span>
                ))}
              </div>
            </div>
            <div style={{ display:'flex', gap:16, flexWrap:'wrap' }}>
              {[
                { label:'Revenus', value:fmt(income), color:'#22d3a0' },
                { label:'Dépenses', value:fmt(expenses), color:'#f5476a' },
                { label:'Solde', value:fmt(balance), color: balance >= 0 ? '#22d3a0' : '#f5476a' },
              ].map((s,i)=>(
                <div key={i} style={{ textAlign:'center' }}>
                  <div style={{ fontSize:18, fontWeight:800, color:s.color, fontFamily:'JetBrains Mono,monospace' }}>{s.value}</div>
                  <div style={{ fontSize:11, color:'var(--text3)' }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div style={{ display:'flex', gap:6, marginBottom:20, flexWrap:'wrap' }}>
        {GROUPS.map(g => (
          <button key={g.key} onClick={()=>setActiveGroup(g.key)} style={{
            display:'flex', alignItems:'center', gap:7, padding:'8px 16px',
            borderRadius:10, border:'none', cursor:'pointer', fontFamily:'inherit',
            fontSize:13, fontWeight:600, transition:'all .15s',
            background: activeGroup===g.key ? 'rgba(124,108,252,.15)' : 'var(--surface2)',
            color: activeGroup===g.key ? 'var(--accent2)' : 'var(--text2)',
            outline: activeGroup===g.key ? '1px solid rgba(124,108,252,.2)' : 'none',
          }}>
            <span>{g.icon}</span>
            <span>{g.label}</span>
            {counts[g.key] > 0 && (
              <span style={{
                fontSize:10, fontWeight:700, padding:'1px 6px', borderRadius:100,
                background: activeGroup===g.key ? 'rgba(124,108,252,.3)' : 'var(--surface3)',
                color: activeGroup===g.key ? 'var(--accent2)' : 'var(--text3)',
              }}>{counts[g.key]}</span>
            )}
          </button>
        ))}
        {dismissed.size > 0 && (
          <button className="btn btn-ghost btn-sm" style={{ marginLeft:'auto' }} onClick={()=>setDismissed(new Set())}>
            Restaurer ({dismissed.size})
          </button>
        )}
      </div>

      {/* Contenu */}
      {loading ? (
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {[1,2,3,4].map(i => <Sk key={i} h={76} r={12}/>)}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={allInsights.length === 0 ? '✨' : '🔍'}
          title={allInsights.length === 0 ? 'Tout va bien !' : 'Aucun insight dans cette catégorie'}
          message={allInsights.length === 0
            ? 'Aucune alerte ni anomalie détectée. Continuez comme ça !'
            : 'Sélectionnez un autre groupe ou consultez tous les insights.'}
        />
      ) : (
        /* Regroupé par section si "all" */
        activeGroup === 'all'
          ? Object.entries(
              filtered.reduce((acc, ins) => {
                if (!acc[ins.group]) acc[ins.group] = []
                acc[ins.group].push(ins)
                return acc
              }, {})
            ).map(([group, items]) => {
              const meta = GROUP_META[group] ?? { title: group, color:'var(--accent2)', bg:'var(--surface2)' }
              return (
                <div key={group} style={{ marginBottom:24 }}>
                  <div style={{
                    display:'flex', alignItems:'center', gap:10, marginBottom:12,
                    padding:'10px 14px', borderRadius:10, background:meta.bg,
                    border:`1px solid ${meta.color}22`,
                  }}>
                    <div style={{ width:3, height:20, borderRadius:2, background:meta.color, flexShrink:0 }}/>
                    <div>
                      <div style={{ fontSize:13, fontWeight:700, color:meta.color }}>{meta.title}</div>
                      <div style={{ fontSize:11, color:'var(--text3)' }}>{meta.subtitle}</div>
                    </div>
                    <span style={{ marginLeft:'auto', fontSize:11, fontWeight:700, color:meta.color, background:`${meta.color}20`, padding:'2px 8px', borderRadius:100 }}>
                      {items.length}
                    </span>
                  </div>
                  <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
                    {items.map(ins => (
                      <div key={ins.id} style={{ position:'relative' }}>
                        <InsightCard insight={ins}/>
                        <button
                          onClick={() => dismiss(ins.id)}
                          title="Ignorer"
                          style={{
                            position:'absolute', top:10, right:10,
                            background:'transparent', border:'none', cursor:'pointer',
                            color:'var(--text3)', fontSize:14, padding:'2px 6px', borderRadius:6,
                            transition:'color .15s',
                          }}
                          onMouseEnter={e=>e.currentTarget.style.color='var(--text)'}
                          onMouseLeave={e=>e.currentTarget.style.color='var(--text3)'}
                        >✕</button>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })
          : (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {filtered.map(ins => (
                <div key={ins.id} style={{ position:'relative' }}>
                  <InsightCard insight={ins}/>
                  <button onClick={()=>dismiss(ins.id)} title="Ignorer" style={{
                    position:'absolute', top:10, right:10, background:'transparent', border:'none',
                    cursor:'pointer', color:'var(--text3)', fontSize:14, padding:'2px 6px', borderRadius:6, transition:'color .15s'
                  }}
                  onMouseEnter={e=>e.currentTarget.style.color='var(--text)'}
                  onMouseLeave={e=>e.currentTarget.style.color='var(--text3)'}>✕</button>
                </div>
              ))}
            </div>
          )
      )}
    </div>
  )
}
