import { useState, useEffect, useCallback } from 'react'
import { useAuth } from '../context/AuthContext'
import { analyticsAPI } from '../services/api'
import { useFinanceCalcs } from '../hooks/useFinanceData'
import { StatCard, ChartCard, ChartTooltip, PeriodFilter, ProgressRow, EmptyState, Sk } from '../components/ui'
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, ReferenceLine, Area, AreaChart,
} from 'recharts'

const formatXOF = (n, digits = 0) =>
  new Intl.NumberFormat('fr-FR', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(Number(n) || 0) + ' FCFA'

const fmt = n => formatXOF(n, 0)
const fmtPct = n => `${(n ?? 0).toFixed(1)}%`
const PERIOD_OPTIONS = [{ value:'3', label:'3 mois' }, { value:'6', label:'6 mois' }, { value:'12', label:'1 an' }]
const CAT_PALETTE = ['#7c6cfc','#f5476a','#22d3a0','#f59e0b','#38bdf8','#a78bfa','#fb923c','#4ade80']

function CustomProjectionDot(props) {
  const { cx, cy, payload } = props
  if (!payload?.isProjection) return <g/>
  return <circle cx={cx} cy={cy} r={5} fill="#f59e0b" stroke="var(--surface)" strokeWidth={2}/>
}

export default function Analytics() {
  const { user } = useAuth()
  const [stats,   setStats]   = useState(null)
  const [monthly, setMonthly] = useState([])
  const [catExp,  setCatExp]  = useState([])
  const [loading, setLoading] = useState(true)
  const [err,     setErr]     = useState(null)
  const [period,  setPeriod]  = useState('6')
  const [chartType, setChartType] = useState('area')

  const load = useCallback(async () => {
    setLoading(true); setErr(null)
    try {
      const [d, m, c] = await Promise.all([
        analyticsAPI.dashboard(user.id),
        analyticsAPI.monthlyExpenses(user.id),
        analyticsAPI.categoryExpenses(user.id),
      ])
      setStats(d?.data ?? d)
      setMonthly(Array.isArray(m) ? m : (m?.data ?? []))
      setCatExp(Array.isArray(c) ? c : (c?.data ?? []))
    } catch(e) { setErr(e.message) }
    finally { setLoading(false) }
  }, [user.id])

  useEffect(() => { load() }, [load])

  const filteredMonthly = monthly.slice(-parseInt(period))
  const calcs = useFinanceCalcs({ stats, monthly: filteredMonthly, catExp })
  const {
    income, expenses, savingsRate, expenseRatio,
    avgMonthlyExpense, avgMonthlyIncome,
    expGrowth, incGrowth, worstMonth,
    topCatName, topCatShare, topCatColor, totalCatExp,
    projectedNextExpense, anomaly, monthlyWithProjection, curr, prev,
  } = calcs

  const pieData = catExp.map((c,i) => ({
    name:  c.category?.name ?? c.category ?? c.name ?? `Cat ${i+1}`,
    value: c.amount ?? c.total ?? 0,
    color: c.category?.color ?? c.color ?? CAT_PALETTE[i % CAT_PALETTE.length],
  })).sort((a,b) => b.value - a.value)

  return (
    <div className="fade-up" style={{ padding:24 }}>

      {/* Header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:24, flexWrap:'wrap', gap:12 }}>
        <div>
          <div className="page-title">Analytics</div>
          <div className="page-subtitle">Analyse approfondie de vos finances</div>
        </div>
        <PeriodFilter value={period} onChange={setPeriod} options={PERIOD_OPTIONS}/>
      </div>

      {err && <div className="error-box" style={{ marginBottom:20 }}>{err} <button className="btn btn-ghost btn-sm" style={{ marginLeft:8 }} onClick={load}>Réessayer</button></div>}

      {/* KPIs */}
      <div style={{ display:'flex', gap:12, marginBottom:20, flexWrap:'wrap' }}>
        <StatCard label="Revenus" value={loading?'—':fmt(income)} color="#22d3a0" icon="↑" loading={loading} trend={incGrowth} trendLabel="vs préc." sub="Cette période"/>
        <StatCard label="Dépenses" value={loading?'—':fmt(expenses)} color="#f5476a" icon="↓" loading={loading} trend={expGrowth} trendLabel="vs préc." sub="Cette période"/>
        <StatCard label="Taux d'épargne" value={loading?'—':fmtPct(savingsRate)} color="#7c6cfc" icon="✦" loading={loading} sub={savingsRate>=20?'✓ Objectif atteint':'Objectif : 20%'}/>
        <StatCard label="Ratio dép./rev." value={loading?'—':fmtPct(expenseRatio)} color="#f59e0b" icon="◎" loading={loading} sub="Idéal < 80%"/>
      </div>

      {/* Métriques avancées */}
      {!loading && (
        <div style={{ display:'flex', gap:10, marginBottom:20, flexWrap:'wrap' }}>
          {[
            { label:'Moy. mensuelle', value:fmt(avgMonthlyExpense), sub:'Dépenses / mois', color:'var(--text)' },
            worstMonth?.month && { label:'Mois le + chargé', value:worstMonth.month, sub:fmt(worstMonth.expenses??0), color:'#f59e0b' },
            projectedNextExpense!=null && { label:'Projection M+1', value:fmt(projectedNextExpense), sub:'Tendance linéaire', color:'#f59e0b', border:true },
            topCatName && { label:'Catégorie dominante', value:topCatName, sub:`${topCatShare.toFixed(0)}% des dépenses`, color:'var(--text)', accent:topCatColor },
            anomaly && { label:'🔥 Anomalie', value:anomaly.month, sub:`+${anomaly.deviation.toFixed(0)}% vs moyenne`, color:'#f5476a', alert:true },
          ].filter(Boolean).map((item,i) => (
            <div key={i} className="card" style={{
              padding:'14px 18px', flex:'1 1 130px',
              borderLeft: item.border ? '2px solid #f59e0b' : item.alert ? '2px solid #f5476a' : item.accent ? `2px solid ${item.accent}` : undefined,
              background: item.alert ? 'rgba(245,71,106,.04)' : undefined,
            }}>
              <div style={{ fontSize:10, fontWeight:600, color: item.alert ? '#f5476a' : 'var(--text3)', textTransform:'uppercase', letterSpacing:'.04em', marginBottom:5 }}>{item.label}</div>
              <div style={{ fontSize:17, fontWeight:800, color:item.color, fontFamily:'JetBrains Mono,monospace' }}>{item.value}</div>
              <div style={{ fontSize:11, color:'var(--text3)', marginTop:3 }}>{item.sub}</div>
            </div>
          ))}
        </div>
      )}

      {/* Chart principal */}
      <ChartCard
        title="Évolution mensuelle"
        subtitle={projectedNextExpense ? 'Point jaune = projection mois suivant' : 'Revenus vs dépenses dans le temps'}
        loading={loading} height={260} style={{ marginBottom:16 }}
        action={
          <div style={{ display:'flex', background:'var(--surface2)', borderRadius:8, border:'1px solid var(--border)', overflow:'hidden' }}>
            {[['area','∿'],['bar','▬']].map(([v,ic])=>(
              <button key={v} onClick={()=>setChartType(v)} style={{
                padding:'6px 12px', border:'none', cursor:'pointer', fontFamily:'inherit', fontSize:13,
                background: chartType===v ? 'rgba(124,108,252,.2)' : 'transparent',
                color: chartType===v ? 'var(--accent2)' : 'var(--text3)',
                transition:'all .15s',
              }}>{ic}</button>
            ))}
          </div>
        }
      >
        {filteredMonthly.length === 0
          ? <EmptyState icon="📊" title="Pas de données" message="Ajoutez des transactions pour voir les graphiques."/>
          : <ResponsiveContainer width="100%" height={260}>
              {chartType === 'area' ? (
                <AreaChart data={monthlyWithProjection}>
                  <defs>
                    <linearGradient id="gInc" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#7c6cfc" stopOpacity={0.18}/>
                      <stop offset="100%" stopColor="#7c6cfc" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="gExp" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f5476a" stopOpacity={0.15}/>
                      <stop offset="100%" stopColor="#f5476a" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,.04)" vertical={false}/>
                  <XAxis dataKey="month" tick={{ fill:'var(--text3)', fontSize:12 }} axisLine={false} tickLine={false}/>
                  <YAxis tick={{ fill:'var(--text3)', fontSize:11 }} axisLine={false} tickLine={false} tickFormatter={v=>`$${(v/1000).toFixed(0)}k`}/>
                  <Tooltip content={<ChartTooltip/>}/>
                  <Legend iconType="circle" iconSize={7} formatter={v=><span style={{fontSize:12,color:'var(--text2)'}}>{v}</span>}/>
                  {avgMonthlyExpense > 0 && (
                    <ReferenceLine y={avgMonthlyExpense} stroke="#f59e0b" strokeDasharray="4 4"
                      label={{ value:'Moy.', fill:'#f59e0b', fontSize:10, position:'insideTopRight' }}/>
                  )}
                  <Area type="monotone" dataKey="income"   stroke="#7c6cfc" strokeWidth={2.5} fill="url(#gInc)" name="Revenus"  dot={false} activeDot={{ r:5, strokeWidth:0 }}/>
                  <Area type="monotone" dataKey="expenses" stroke="#f5476a" strokeWidth={2.5} fill="url(#gExp)" name="Dépenses" dot={<CustomProjectionDot/>} activeDot={{ r:5, strokeWidth:0 }}/>
                </AreaChart>
              ) : (
                <BarChart data={filteredMonthly} barSize={14} barGap={4}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,.04)" vertical={false}/>
                  <XAxis dataKey="month" tick={{ fill:'var(--text3)', fontSize:12 }} axisLine={false} tickLine={false}/>
                  <YAxis tick={{ fill:'var(--text3)', fontSize:11 }} axisLine={false} tickLine={false} tickFormatter={v=>`$${(v/1000).toFixed(0)}k`}/>
                  <Tooltip content={<ChartTooltip/>}/>
                  <Legend iconType="circle" iconSize={7} formatter={v=><span style={{fontSize:12,color:'var(--text2)'}}>{v}</span>}/>
                  <Bar dataKey="income"   fill="#7c6cfc" name="Revenus"  radius={[4,4,0,0]}/>
                  <Bar dataKey="expenses" fill="#f5476a" name="Dépenses" radius={[4,4,0,0]}/>
                </BarChart>
              )}
            </ResponsiveContainer>
        }
      </ChartCard>

      {/* Pie + breakdown */}
      <div style={{ display:'flex', gap:16, marginBottom:16, flexWrap:'wrap' }}>
        <ChartCard title="Répartition dépenses" subtitle="Par catégorie" loading={loading} height={190} style={{ flex:'1 1 240px' }}>
          {pieData.length === 0 ? <EmptyState icon="🥧" title="Aucune catégorie"/> :
            <ResponsiveContainer width="100%" height={190}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={82} paddingAngle={2} dataKey="value">
                  {pieData.map((d,i) => <Cell key={i} fill={d.color}/>)}
                </Pie>
                <Tooltip formatter={v=>[fmt(v),'Montant']} contentStyle={{ background:'var(--surface2)', border:'1px solid var(--border2)', borderRadius:8, fontSize:13 }}/>
              </PieChart>
            </ResponsiveContainer>
          }
        </ChartCard>

        <div className="card" style={{ flex:'2 1 280px', padding:24 }}>
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:15, fontWeight:700, color:'var(--text)' }}>Détail par catégorie</div>
            <div style={{ fontSize:13, color:'var(--text2)', marginTop:3 }}>% des dépenses totales</div>
          </div>
          {loading ? [1,2,3,4].map(i=><Sk key={i} h={18} style={{ marginBottom:16 }}/>) :
            pieData.length === 0 ? <EmptyState icon="📂" title="Aucune catégorie"/> :
            pieData.map((d,i) => <ProgressRow key={i} label={d.name} value={d.value} max={totalCatExp} color={d.color}/>)
          }
        </div>
      </div>

      {/* Comparaison mois */}
      {!loading && curr && prev && (
        <div className="card" style={{ padding:24 }}>
          <div style={{ marginBottom:18 }}>
            <div style={{ fontSize:15, fontWeight:700, color:'var(--text)' }}>Comparaison mensuelle</div>
            <div style={{ fontSize:13, color:'var(--text2)', marginTop:3 }}>{prev.month} → {curr.month}</div>
          </div>
          <div style={{ display:'flex', gap:12, flexWrap:'wrap' }}>
            {[
              { label:'Revenus',  curr:curr.income??0,   prev:prev.income??0,   positiveIsGood:true  },
              { label:'Dépenses', curr:curr.expenses??0, prev:prev.expenses??0, positiveIsGood:false },
              { label:'Épargne',  curr:(curr.income??0)-(curr.expenses??0), prev:(prev.income??0)-(prev.expenses??0), positiveIsGood:true },
            ].map((row,i) => {
              const delta = row.prev > 0 ? ((row.curr-row.prev)/row.prev)*100 : 0
              const up    = delta > 0
              const good  = row.positiveIsGood ? up : !up
              return (
                <div key={i} style={{ flex:'1 1 150px', padding:'16px 18px', background:'var(--surface2)', borderRadius:12, border:'1px solid var(--border)' }}>
                  <div style={{ fontSize:11, fontWeight:600, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.04em', marginBottom:8 }}>{row.label}</div>
                  <div style={{ fontSize:20, fontWeight:800, color:'var(--text)', fontFamily:'JetBrains Mono,monospace', marginBottom:6 }}>{fmt(row.curr)}</div>
                  <div style={{ fontSize:12, color: good ? '#22d3a0' : '#f5476a', fontWeight:600 }}>
                    {up?'↑':'↓'} {Math.abs(delta).toFixed(1)}% vs {fmt(row.prev)}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
